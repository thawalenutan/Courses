

function displayAllPost(){
    window.location.href = "../html/postslist.html";
}

function createPost() {
    var createPost = document.getElementById('createPostModal');
    createPost.style.display = 'block';
}

